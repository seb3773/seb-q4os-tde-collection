sudo cp -rf ./WindozeXP /usr/share/plymouth/themes && sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/MyLinuxMint/MyLinuxMint.plymouth 100 && sudo update-alternatives --config default.plymouth && sudo update-initramfs -u && sudo reboot


