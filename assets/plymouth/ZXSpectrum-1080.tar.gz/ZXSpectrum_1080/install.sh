#!/bin/bash
sudo cp -r ZXSpectrum /usr/share/plymouth/themes
sudo plymouth-set-default-theme -R ZXSpectrum
